﻿// T2208
// Program 1A
// Due: 2-12-2020
// CIS 200-01
// This program creates a series of classes in heirarchy that a library might have. It demonstrates the use
// of inheritance 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public class LibraryBook : LibraryItem
    {
        private string _author;     // The book's author

        public LibraryBook(String theTitle, String theAuthor, String thePublisher,
            int theCopyrightYear, int theLoanPeriod, String theCallNumber)
            :base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            Author = theAuthor;
        }

        public string Author
        {
            // Precondition:  None
            // Postcondition: The author has been returned
            get
            {
                return _author;
            }

            // Precondition:  None
            // Postcondition: The author has been set to the specified value
            set
            {
                // Since empty author is OK, just change null to empty string
                _author = (value == null ? string.Empty : value.Trim());
            }
        }

        // Precondition:  None
        // Postcondition: The fee is calculated and returned.
        public override decimal CalcLateFee(int daysLate)
        {
            const decimal FEE_PER_DAY = 0.25M;  // Constant late fee of $0.25 a day

            decimal total = FEE_PER_DAY * daysLate;
            return total;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the library magazine's data on separate lines.
        public override string ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut

            return $"Title: {Title}{NL}Author: {Author}{NL}Publisher: {Publisher}{NL}" +
                $"Copyright: {CopyrightYear}{NL}Loan Period: {LoanPeriod}{NL}Call Number: {CallNumber}{NL}";
        }
    }
}