﻿// T2208
// Program 1A
// Due: 2-12-2020
// CIS 200-01
// This program creates a series of classes in heirarchy that a library might have. It demonstrates the use
// of inheritance 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public class LibraryMovie : LibraryMediaItem
    {
        private string _director;
        private MediaType _medium;
        private MPAARatings _rating;

        // Stores all the possible ratings for the movie in an Enumerated List
        public enum MPAARatings
        {
            G,
            PG,
            PG13,
            R,
            NC17,
            U
        }

        // Precondition:  None
        // Postcondition: The Library Magazine has been initialized with the specified 
        //                title, publisher, copyright year, loan period, call number,
        //                duration, director, medium, and rating.
        public LibraryMovie(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod,
            string theCallNumber, double theDuration, string theDirector, MediaType theMedium, MPAARatings theRating)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theDuration)
        {
            Director = theDirector;
            Medium = theMedium;
            Rating = theRating;
        }

        // Precondition: Value must not be null or white space
        // Postcondition: Returns the director
        public string Director
        {
            get
            {
                return _director;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentOutOfRangeException($"{nameof(Director)}", value, 
                        $"{nameof(Director)} please enter a Director.");
                else
                    _director = value.Trim();
            }
        }

        // Precondition: Value must be DVD, BLURAY, or VHS.
        // Postcondition: medium is returned.
        public override MediaType Medium
        {
            get
            {
                return _medium;
            }
            set
            {
                if (value <= MediaType.VHS)
                    _medium = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Medium)}", value, 
                        $"{nameof(Medium)} please enter a valid medium for the movie (DVD, BLURAY, VHS).");
            }
        }

        // Precondition: The value has to be one of the values in the enumerated list
        // Postcondition: The rating is returned
        public MPAARatings Rating
        {
            get
            {
                return _rating;
            }
            set
            {
                if (value <= MPAARatings.U)
                    _rating = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Rating)}", value, 
                        $"{nameof(Rating)} please enter a valid MPAA Rating");
            }
        }

        // Precondition:  None
        // Postcondition: The fee is calculated and returned.
        public override decimal CalcLateFee(int daysLate)
        {
            const decimal FEE_DVD_VHS = 1.00M;      // Constant fee of $1.00 per day late for DVD and VHS
            const decimal FEE_BLURAY = 1.50M;       // Constant fee of $1.50 per day late for BLURAY
            const decimal MAX_FEE = 25.00M;         // Constant max fee of $25.00

            decimal totalFee;

            if (this.Medium == MediaType.DVD)
            {
                if (daysLate * FEE_DVD_VHS >= MAX_FEE)
                    totalFee = MAX_FEE;
                else
                    totalFee = daysLate * FEE_DVD_VHS;
            }
            else
            {
                if (daysLate * FEE_BLURAY >= MAX_FEE)
                    totalFee = MAX_FEE;
                else
                    totalFee = daysLate * FEE_BLURAY;
            }
            return totalFee;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the library movie's data on separate lines.
        public override string ToString()
        {
            string NL = Environment.NewLine;    // New line shortcut

            return $"Title: {Title}{NL}Publisher: {Publisher}{NL}Copyright: {CopyrightYear}{NL}" +
                $"Call Number: {CallNumber}{NL}Duration: {Duration}{NL}" +
                $"Director: {Director}{NL}Media Type: {Medium}{NL}Rating: {Rating}";
        }
    }
}
