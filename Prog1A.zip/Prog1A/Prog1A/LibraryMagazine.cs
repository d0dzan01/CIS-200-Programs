﻿// T2208
// Program 1A
// Due: 2-12-2020
// CIS 200-01
// This program creates a series of classes in heirarchy that a library might have. It demonstrates the use
// of inheritance 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public class LibraryMagazine : LibraryPeriodical
    {
        // Precondition:  None
        // Postcondition: The Library Magazine has been initialized with the specified 
        //                title, publisher, copyright year, loan period, call number, volume, and number
        public LibraryMagazine(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod,
            string theCallNumber, int theVolume, int theNumber)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theVolume, theNumber)
        {

        }

        // Precondition:  None
        // Postcondition: The fee is calculated and returned.
        public override decimal CalcLateFee(int daysLate)
        {
            const decimal FEE = 0.25M;          // Constant fee rate of $0.25 a day
            const decimal MAX_FEE = 20.00M;     // Maximum fee of $20
            decimal feeTotal;

            if (daysLate * FEE >= MAX_FEE)
                feeTotal = MAX_FEE;
            else
                feeTotal = daysLate * FEE;

            return feeTotal;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the library magazine's data on separate lines.
        public override string ToString()
        {
            string NL = Environment.NewLine; // New line shortcut

            return $"Title: {Title}{NL}Publisher: {Publisher}{NL}Copyright Year: {CopyrightYear}{NL}" +
                $"Call Number: {CallNumber}{NL}Volume: {Volume}{NL}Number: {Number}{NL}";
        }
    }
}
