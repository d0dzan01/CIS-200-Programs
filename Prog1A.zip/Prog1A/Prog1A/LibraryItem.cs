﻿// T2208
// Program 1A
// Due: 2-12-2020
// CIS 200-01
// This program creates a series of classes in heirarchy that a library might have. It demonstrates the use
// of inheritance 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public abstract class LibraryItem
    {
        private string _title;
        private string _publisher;
        private int _copyrightYear;
        private int _loanPeriod;
        private string _callNumber;

        // Precondition: None
        // Postcondition: The Library Item has been initialized with the specified 
        //                title, publisher, copyright year, loan period, call number
        public LibraryItem(String theTitle, String thePublisher, int theCopyrightYear,
            int theLoanPeriod, String theCallNumber)
        {
            Title = theTitle;
            Publisher = thePublisher;
            CopyrightYear = theCopyrightYear;
            LoanPeriod = theLoanPeriod;
            CallNumber = theCallNumber;

            ReturnToShelf();
        }

        // Precondition:  Value cannot be null or white space
        // Postcondition: Returns the title
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(Title)}", value,
                        $"{nameof(Title)} must not be null or empty");
                else
                    _title = value.Trim();
            }
        }

        // Precondition:  value must not be null or white space
        // Postcondition: returns the publisher
        public string Publisher
        {
            get
            {
                return _publisher;
            }
            set
            {
                _publisher = (value == null ? string.Empty : value.Trim());
            }
        }

        // Precondition:  value must be greater than 0
        // Postcondition: returns the copyright year
        public int CopyrightYear
        {
            get
            {
                return _copyrightYear;
            }
            set
            {
                if (value >= 0)
                    _copyrightYear = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(CopyrightYear)}", value,
                        $"{nameof(CopyrightYear)} must be >= 0");
            }
        }

        // Precondition:  vlaue must be greater than or equal to 0
        // Postcondition: returns loan period
        public int LoanPeriod
        {
            get
            {
                return _loanPeriod;
            }
            set
            {
                if (value >= 0)
                    _loanPeriod = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(LoanPeriod)}", value,
                        $"{nameof(LoanPeriod)} must be >= 0");
            }
        }

        // Precondition:  Value must not be null or white space
        // Postcondition: Returns the call number
        public string CallNumber
        {
            get
            {
                return _callNumber;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(CallNumber)}", value,
                        $"{nameof(CallNumber)} must not be null or empty");
                else
                    _callNumber = value.Trim();
            }
        }

        public LibraryPatron Patron
        {
            // Precondition:  None
            // Postcondition: The book's patron has been returned
            get; 

            // Helper
            // Precondition:  None
            // Postcondition: The book's patron has been set to the specified value
            private set; 
        }

        public void CheckOut(LibraryPatron thePatron)
        {
            if (thePatron != null)
                Patron = thePatron;
            else
                throw new ArgumentNullException($"{nameof(thePatron)}", $"{nameof(thePatron)} must not be null");
        }

        // Precondition:  None
        // Postcondition: The book is not checked out
        public void ReturnToShelf()
        {
            Patron = null; // Remove previously stored reference to patron
        }

        // Precondition:  None
        // Postcondition: true is returned if the book is checked out,
        //                otherwise false is returned
        public bool IsCheckedOut()
        {
            return Patron != null; // The item is checked out if there is a Patron
        }

        // Precondition: None
        // Postcondition: None
        public abstract decimal CalcLateFee(int daysLate);

        // Precondition:  None
        // Postcondition: A string is returned representing the library item's data on separate lines.
        public override string ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut

            return $"Title: {Title}{NL}Publisher: {Publisher}{NL}" +
            $"Copyright: {CopyrightYear}{NL}Loan Period: {LoanPeriod}{NL}Call Number: {CallNumber}{NL}";
        }

    }
}
