﻿// T2208
// Program 1A
// Due: 2-12-2020
// CIS 200-01
// This program creates a series of classes in heirarchy that a library might have. It demonstrates the use
// of inheritance 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public class LibraryPeriodical : LibraryItem
    {

        private int _volume;
        private int _number;

        // Precondition:  None
        // Postcondition: The Library Periodical has been initialized with the specified 
        //                title, publisher, copyright year, loan period, call number, volume, and number
        public LibraryPeriodical(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod,
            string theCallNumber, int theVolume, int theNumber)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            Volume = theVolume;
            Number = theNumber;
        }

        // Precondition:  Volume value must be greater than or equal to 1
        // Postcondition: Returns the volume
        public int Volume
        {
            get
            {
                return _volume;
            }
            set
            {
                if (value >= 1)
                    _volume = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Volume)}", value,
                        $"{nameof(Volume)} must be greater than or equal to one.");
            }
        }

        // Precondition:  Number value must be greater than or equal to 1
        // Postcondition: Returns the number
        public int Number
        {
            get
            {
                return _number;
            }
            set
            {
                if (value >= 1)
                    _number = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Number)}", value,
                        $"{nameof(Number)} must be greater than or equal to one.");
            }
        }

        // Precondition:  None
        // Postcondition: None - There should not be a fee assosciated with this class, only the derived classes
        public override decimal CalcLateFee(int daysLate)
        {
            throw new NotImplementedException();
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the library periodical's data on separate lines.
        public override string ToString()
        {
            string NL = Environment.NewLine;

            return $"Title: {Title}{NL}Publisher: {Publisher}{NL}Copyright Year: {CopyrightYear}{NL}" +
                $"Call Number: {CallNumber}{NL}Volume: {Volume}{NL}Number: {Number}{NL}";
        }
    }
}
