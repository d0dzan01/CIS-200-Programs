﻿// T2208
// Program 1A
// Due: 2-12-2020
// CIS 200-01
// This program creates a series of classes in heirarchy that a library might have. It demonstrates the use
// of inheritance 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public class LibraryMusic : LibraryMediaItem
    {
        private string _artist;
        private MediaType _medium;
        private int _tracks;

        // Precondition: None
        // Postcondition: The Library Music has been initialized with the specified 
        //                title, publisher, copyright year, loan period, call number,
        //                duration, artist, medium, and number of tracks
        public LibraryMusic(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod,
            string theCallNumber, double theDuration, string theArtist, MediaType theMedium, int theTracks)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theDuration)
        {
            Artist = theArtist;
            Medium = theMedium;
            Tracks = theTracks;
        }

        // Precondition: Value must not be Null or Whitespace
        // Postcondition: Returns the Artist
        public string Artist
        {
            get
            {
                return _artist;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentOutOfRangeException($"{nameof(Artist)}", value, 
                        $"{nameof(Artist)} please enter an Artist");
                else
                    _artist = value.Trim();
            }
        }

        // Precondition: Medium value must be CD, SACD, or VINYL.
        // Postcondition: Returns the Medium.
        public override MediaType Medium
        {
            get
            {
                return _medium;
            }
            set
            {
                if (value >= MediaType.CD)
                    _medium = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Medium)}", value, 
                        $"{nameof(Medium)} please enter a valid medium (CD, SACD, or VINYL).");
            }
        }

        // Precondition: Number of Tracks value must be greater than or equal to 1.
        // Postcondition: Returns the number of tracks.
        public int Tracks
        {
            get
            {
                return _tracks;
            }
            set
            {
                if (value >= 1)
                    _tracks = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Tracks)}", value, 
                        $"{nameof(Tracks)} must be greater than or equal to one.");
            }
        }

        // Precondition:  None
        // Postcondition: The fee is calculated and returned.
        public override decimal CalcLateFee(int daysLate)
        {
            const decimal FEE = 0.50M;          // Constant late fee of $0.50 a day.
            const decimal MAX_FEE = 20.00M;     // Constant max late fee of $20.
            decimal feeTotal;   

            if (daysLate * FEE >= MAX_FEE)
                feeTotal = MAX_FEE;
            else
                feeTotal = daysLate * FEE;

            return feeTotal;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the library music's data on separate lines.
        public override string ToString()
        {
            string NL = Environment.NewLine;    // Shortcut for new line

            return $"Title: {Title}{NL}Artist: {Artist}{NL}Publisher: {Publisher}{NL}" +
                $"Copyright: {CopyrightYear}{NL}Call Number: {CallNumber}{NL}" +
                $"Duration: {Duration}{NL}Artist: {Artist}{NL}Media Type: {Medium}{NL}Number of Tracks: {Tracks}{NL}";
        }
    }
}
