﻿// T2208
// Program 1A
// Due: 2-12-2020
// CIS 200-01
// This program creates a series of classes in heirarchy that a library might have. It demonstrates the use
// of inheritance 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public abstract class LibraryMediaItem : LibraryItem
    {
        private double _duration;

        // Precondition:  None
        // Postcondition: The Library Media Item has been initialized with the specified 
        //                title, publisher, copyright year, loan period, call number, and duration
        public LibraryMediaItem(string theTitle, string thePublisher, int theCopyrightYear,
            int theLoanPeriod, string theCallNumber, double theDuration)
            :base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            Duration = theDuration;
        }

        // creates an enumerated list of Media Types
        public enum MediaType
        { 
            DVD,
            BLURAY,
            VHS,
            CD,
            SACD,
            VINYL
        }

        public double Duration
        {
            // Precondition:  None
            // Postcondition: The duration has been returned
            get
            {
                return _duration;
            }

            // Precondition:  value >= 0
            // Postcondition: The duration has been set to the specified value
            set
            {
                if (value >= 0)
                    _duration = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Duration)}", value,
                        $"{nameof(Duration)} must be >= 0");
            }
        }

        // Precondition: None
        // Postcondition: None
        public abstract MediaType Medium
        {
            get;
            set;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the library magazine's data on separate lines.
        public override string ToString()
        {
            string NL = Environment.NewLine; // NewLine shortcut

            return $"Title: {Title}{NL}Publisher: {Publisher}{NL}Copyright: {CopyrightYear}{NL}" +
                $"Loan Period: {LoanPeriod}{NL}Call Number: {CallNumber}{NL}Duration: {Duration}{NL}";
        }
    }
}
