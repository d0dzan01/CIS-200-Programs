﻿// T2208
// Program 1A
// Due: 2-12-2020
// CIS 200-01
// This program creates a series of classes in heirarchy that a library might have. It demonstrates the use
// of inheritance 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1A
{
    public class LibraryJournal : LibraryPeriodical
    {
        private string _discipline;
        private string _editor;

        // Precondition:  None
        // Postcondition: The Library Journal has been initialized with the specified 
        //                title, publisher, copyright year, loan period, call number, volume,
        //                number, discipline, and editor.
        public LibraryJournal(string theTitle, string thePublisher, int theCopyrightYear, int theLoanPeriod,
            string theCallNumber, int theVolume, int theNumber, string theDiscipline, string theEditor)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theVolume, theNumber)
        {
            Discipline = theDiscipline;
            Editor = theEditor;
        }

        public string Discipline
        {
            // Precondition: Value must not be null or whitespace
            // Postcondition: Returns the discipline value
            get
            {
                return _discipline;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentOutOfRangeException($"{nameof(Discipline)}", value,
                        $"{nameof(Discipline)} please enter a Director.");
                else
                    _discipline = value.Trim();
            }
        }

        public string Editor
        {
            // Precondition: Value must not be null or whitespace
            // Postcondition: Returns the editor value
            get
            {
                return _editor;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentOutOfRangeException($"{nameof(Editor)}", value,
                        $"{nameof(Editor)} please enter a Director.");
                else
                    _editor = value.Trim();
            }
        }

        public override decimal CalcLateFee(int daysLate)
        {
            // Precondition:  None
            // Postcondition: The fee is calculated and returned.
            const decimal FEE = 0.75M;      // Constant fee of $0.75 per day late.

            decimal totalFee = daysLate * FEE;
            return totalFee;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the library journal's data on separate lines.
        public override string ToString()
        {
            string NL = Environment.NewLine; // Newline shortcut

            return $"Title: {Title}{NL}Publisher: {Publisher}{NL}Copyright Year: {CopyrightYear}{NL}" +
                $"Call Number: {CallNumber}{NL}Volume: {Volume}{NL}Number: {Number}{NL}" +
                $"Discipline: {Discipline}{NL}Editor: {Editor}{NL}";
        }
    }
}
