﻿// Program 3
// CIS 200-01
// Due: 4/2/2020
// Grading ID: T2208

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class EditBookForm : Form
    {
        private List<LibraryItem> _item;

        public EditBookForm(List<LibraryItem> itemList)
        {
            InitializeComponent();

            _item = itemList;
        }

        // Precondition:  None
        // Postcondition: Populates the combo box with library items
        private void EditBookForm_Load(object sender, EventArgs e)
        {
            foreach (LibraryItem item in _item)
                selectBookCbx.Items.Add($"{item.Title}, {item.CallNumber}");
        }

        // Precondition:  None
        // Postcondition: Returns the item index
        internal int ItemIndex
        {
            get
            {
                return selectBookCbx.SelectedIndex;
            }
            set
            {
                selectBookCbx.SelectedIndex = value;
            }
        }

        // Precondition:  User clicked on okBtn
        // Postcondition: If invalid field on dialog, keep form open and give first invalid
        //                field the focus. Else return OK and close form.
        private void okBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        // Precondition:  User clicked cancelBtn
        // Postcondition: Closes the form.
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
