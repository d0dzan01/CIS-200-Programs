﻿// Program 3
// CIS 200-01
// Due: 4/2/2020
// Grading ID: T2208

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class EditPatronForm : Form
    {
        private List<LibraryPatron> _patrons;

        // Precondition:  List patronList is populated with the available
        //                LibraryPatrons to choose from
        // Postcondition: The form's GUI is prepared for display.
        public EditPatronForm(List<LibraryPatron> patronList)
        {
            InitializeComponent();

            _patrons = patronList;

        }

        // Precondition:  None
        // Postcondition: Populates the combobox with patrons
        private void EditPatronForm_Load(object sender, EventArgs e)
        {
            foreach (LibraryPatron patron in _patrons)
                selectPatCbx.Items.Add($"{patron.PatronName}, {patron.PatronID}");
        }

        // Precondition:  None
        // Postcondition: Returns the patron index
        internal int PatIndex
        {
            get
            {
                return selectPatCbx.SelectedIndex;
            }
            set
            {
                selectPatCbx.SelectedIndex = value;
            }
        }

        // Precondition:  User clicked on okBtn
        // Postcondition: If invalid field on dialog, keep form open and give first invalid
        //                field the focus. Else return OK and close form.
        private void okBtn_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        // Precondition:  User clicked cancelBtn
        // Postcondition: Closes the form.
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
