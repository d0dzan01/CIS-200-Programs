﻿// Program 4
// CIS 200-01
// Due: 4/14/2020
// Grading ID: T2208

// This simple program, when called, sorts the items by copyright year.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    class DecendingCopyrightOrder : Comparer<LibraryItem>
    {
        // Precondition:  None
        // Postcondition: Sorts the library items in REVERSE order
        //                based on the copyright year.
        public override int Compare(LibraryItem x, LibraryItem y)
        {
            return (-1) * x.CopyrightYear.CompareTo(y.CopyrightYear);
        }
    }
}
