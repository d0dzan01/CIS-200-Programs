﻿namespace LibraryItems
{
    partial class NewBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleTxt = new System.Windows.Forms.TextBox();
            this.titleLbl = new System.Windows.Forms.Label();
            this.publisherTxt = new System.Windows.Forms.TextBox();
            this.publisherLbl = new System.Windows.Forms.Label();
            this.copyrightTxt = new System.Windows.Forms.TextBox();
            this.copyrightLbl = new System.Windows.Forms.Label();
            this.loanPeriodTxt = new System.Windows.Forms.TextBox();
            this.loanPeriodLbl = new System.Windows.Forms.Label();
            this.callNumTxt = new System.Windows.Forms.TextBox();
            this.callNumLbl = new System.Windows.Forms.Label();
            this.authorTxt = new System.Windows.Forms.TextBox();
            this.authorLbl = new System.Windows.Forms.Label();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.okBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleTxt
            // 
            this.titleTxt.Location = new System.Drawing.Point(93, 7);
            this.titleTxt.Name = "titleTxt";
            this.titleTxt.Size = new System.Drawing.Size(100, 20);
            this.titleTxt.TabIndex = 3;
            this.titleTxt.Validating += new System.ComponentModel.CancelEventHandler(this.titleTxt_Validating);
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.Location = new System.Drawing.Point(57, 10);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(30, 13);
            this.titleLbl.TabIndex = 2;
            this.titleLbl.Text = "Title:";
            // 
            // publisherTxt
            // 
            this.publisherTxt.Location = new System.Drawing.Point(93, 34);
            this.publisherTxt.Name = "publisherTxt";
            this.publisherTxt.Size = new System.Drawing.Size(100, 20);
            this.publisherTxt.TabIndex = 5;
            // 
            // publisherLbl
            // 
            this.publisherLbl.AutoSize = true;
            this.publisherLbl.Location = new System.Drawing.Point(31, 37);
            this.publisherLbl.Name = "publisherLbl";
            this.publisherLbl.Size = new System.Drawing.Size(56, 13);
            this.publisherLbl.TabIndex = 4;
            this.publisherLbl.Text = "Publisher: ";
            // 
            // copyrightTxt
            // 
            this.copyrightTxt.Location = new System.Drawing.Point(93, 61);
            this.copyrightTxt.Name = "copyrightTxt";
            this.copyrightTxt.Size = new System.Drawing.Size(100, 20);
            this.copyrightTxt.TabIndex = 7;
            this.copyrightTxt.Validating += new System.ComponentModel.CancelEventHandler(this.copyrightTxt_Validating);
            // 
            // copyrightLbl
            // 
            this.copyrightLbl.AutoSize = true;
            this.copyrightLbl.Location = new System.Drawing.Point(33, 64);
            this.copyrightLbl.Name = "copyrightLbl";
            this.copyrightLbl.Size = new System.Drawing.Size(54, 13);
            this.copyrightLbl.TabIndex = 6;
            this.copyrightLbl.Text = "Copyright:";
            // 
            // loanPeriodTxt
            // 
            this.loanPeriodTxt.Location = new System.Drawing.Point(93, 88);
            this.loanPeriodTxt.Name = "loanPeriodTxt";
            this.loanPeriodTxt.Size = new System.Drawing.Size(100, 20);
            this.loanPeriodTxt.TabIndex = 9;
            this.loanPeriodTxt.Validating += new System.ComponentModel.CancelEventHandler(this.loanPeriodTxt_Validating);
            // 
            // loanPeriodLbl
            // 
            this.loanPeriodLbl.AutoSize = true;
            this.loanPeriodLbl.Location = new System.Drawing.Point(20, 91);
            this.loanPeriodLbl.Name = "loanPeriodLbl";
            this.loanPeriodLbl.Size = new System.Drawing.Size(67, 13);
            this.loanPeriodLbl.TabIndex = 8;
            this.loanPeriodLbl.Text = "Loan Period:";
            // 
            // callNumTxt
            // 
            this.callNumTxt.Location = new System.Drawing.Point(93, 115);
            this.callNumTxt.Name = "callNumTxt";
            this.callNumTxt.Size = new System.Drawing.Size(100, 20);
            this.callNumTxt.TabIndex = 11;
            this.callNumTxt.Validating += new System.ComponentModel.CancelEventHandler(this.callNumTxt_Validating);
            // 
            // callNumLbl
            // 
            this.callNumLbl.AutoSize = true;
            this.callNumLbl.Location = new System.Drawing.Point(20, 118);
            this.callNumLbl.Name = "callNumLbl";
            this.callNumLbl.Size = new System.Drawing.Size(67, 13);
            this.callNumLbl.TabIndex = 10;
            this.callNumLbl.Text = "Call Number:";
            // 
            // authorTxt
            // 
            this.authorTxt.Location = new System.Drawing.Point(93, 142);
            this.authorTxt.Name = "authorTxt";
            this.authorTxt.Size = new System.Drawing.Size(100, 20);
            this.authorTxt.TabIndex = 13;
            // 
            // authorLbl
            // 
            this.authorLbl.AutoSize = true;
            this.authorLbl.Location = new System.Drawing.Point(46, 145);
            this.authorLbl.Name = "authorLbl";
            this.authorLbl.Size = new System.Drawing.Size(41, 13);
            this.authorLbl.TabIndex = 12;
            this.authorLbl.Text = "Author:";
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(110, 179);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(75, 23);
            this.cancelBtn.TabIndex = 15;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(29, 179);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(75, 23);
            this.okBtn.TabIndex = 14;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // NewBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(229, 234);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.authorTxt);
            this.Controls.Add(this.authorLbl);
            this.Controls.Add(this.callNumTxt);
            this.Controls.Add(this.callNumLbl);
            this.Controls.Add(this.loanPeriodTxt);
            this.Controls.Add(this.loanPeriodLbl);
            this.Controls.Add(this.copyrightTxt);
            this.Controls.Add(this.copyrightLbl);
            this.Controls.Add(this.publisherTxt);
            this.Controls.Add(this.publisherLbl);
            this.Controls.Add(this.titleTxt);
            this.Controls.Add(this.titleLbl);
            this.Name = "NewBook";
            this.Text = "NewBook";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox titleTxt;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.TextBox publisherTxt;
        private System.Windows.Forms.Label publisherLbl;
        private System.Windows.Forms.TextBox copyrightTxt;
        private System.Windows.Forms.Label copyrightLbl;
        private System.Windows.Forms.TextBox loanPeriodTxt;
        private System.Windows.Forms.Label loanPeriodLbl;
        private System.Windows.Forms.TextBox callNumTxt;
        private System.Windows.Forms.Label callNumLbl;
        private System.Windows.Forms.TextBox authorTxt;
        private System.Windows.Forms.Label authorLbl;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Button okBtn;
    }
}