﻿namespace LibraryItems
{
    partial class CheckOutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.itemCbx = new System.Windows.Forms.ComboBox();
            this.patronCbx = new System.Windows.Forms.ComboBox();
            this.selectItemLbl = new System.Windows.Forms.Label();
            this.selectPatronLbl = new System.Windows.Forms.Label();
            this.okCheckBtn = new System.Windows.Forms.Button();
            this.cancelCheckBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // itemCbx
            // 
            this.itemCbx.FormattingEnabled = true;
            this.itemCbx.Location = new System.Drawing.Point(15, 25);
            this.itemCbx.Name = "itemCbx";
            this.itemCbx.Size = new System.Drawing.Size(260, 21);
            this.itemCbx.TabIndex = 0;
            // 
            // patronCbx
            // 
            this.patronCbx.FormattingEnabled = true;
            this.patronCbx.Location = new System.Drawing.Point(15, 81);
            this.patronCbx.Name = "patronCbx";
            this.patronCbx.Size = new System.Drawing.Size(146, 21);
            this.patronCbx.TabIndex = 1;
            // 
            // selectItemLbl
            // 
            this.selectItemLbl.AutoSize = true;
            this.selectItemLbl.Location = new System.Drawing.Point(12, 9);
            this.selectItemLbl.Name = "selectItemLbl";
            this.selectItemLbl.Size = new System.Drawing.Size(63, 13);
            this.selectItemLbl.TabIndex = 2;
            this.selectItemLbl.Text = "Select Item:";
            // 
            // selectPatronLbl
            // 
            this.selectPatronLbl.AutoSize = true;
            this.selectPatronLbl.Location = new System.Drawing.Point(12, 65);
            this.selectPatronLbl.Name = "selectPatronLbl";
            this.selectPatronLbl.Size = new System.Drawing.Size(74, 13);
            this.selectPatronLbl.TabIndex = 3;
            this.selectPatronLbl.Text = "Select Patron:";
            // 
            // okCheckBtn
            // 
            this.okCheckBtn.Location = new System.Drawing.Point(63, 131);
            this.okCheckBtn.Name = "okCheckBtn";
            this.okCheckBtn.Size = new System.Drawing.Size(75, 23);
            this.okCheckBtn.TabIndex = 4;
            this.okCheckBtn.Text = "OK";
            this.okCheckBtn.UseVisualStyleBackColor = true;
            this.okCheckBtn.Click += new System.EventHandler(this.okCheckBtn_Click);
            // 
            // cancelCheckBtn
            // 
            this.cancelCheckBtn.Location = new System.Drawing.Point(144, 131);
            this.cancelCheckBtn.Name = "cancelCheckBtn";
            this.cancelCheckBtn.Size = new System.Drawing.Size(75, 23);
            this.cancelCheckBtn.TabIndex = 5;
            this.cancelCheckBtn.Text = "Cancel";
            this.cancelCheckBtn.UseVisualStyleBackColor = true;
            // 
            // CheckOutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(295, 182);
            this.Controls.Add(this.cancelCheckBtn);
            this.Controls.Add(this.okCheckBtn);
            this.Controls.Add(this.selectPatronLbl);
            this.Controls.Add(this.selectItemLbl);
            this.Controls.Add(this.patronCbx);
            this.Controls.Add(this.itemCbx);
            this.Name = "CheckOutForm";
            this.Text = "Check Out";
            this.Load += new System.EventHandler(this.CheckOutForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox itemCbx;
        private System.Windows.Forms.ComboBox patronCbx;
        private System.Windows.Forms.Label selectItemLbl;
        private System.Windows.Forms.Label selectPatronLbl;
        private System.Windows.Forms.Button okCheckBtn;
        private System.Windows.Forms.Button cancelCheckBtn;
    }
}