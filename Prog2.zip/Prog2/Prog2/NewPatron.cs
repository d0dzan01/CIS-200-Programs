﻿// Grading ID: T2208
// Program 2
// Due Date: March 8, 2020
// Section 01
// This form creates a new patron and adds it to the list of patrons

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class NewPatron : Form
    {
        public NewPatron()
        {
            InitializeComponent();
        }

        // Precondition:  None
        // Postcondition: Gets and sets the patrons name
        public string Name
        {
            get
            {
                return nameTxt.Text;
            }
            set
            {
                nameTxt.Text = value;
            }
        }

        // Precondition:  None
        // Postcondition: Gets and sets the patrons id number
        public string IdNumber
        {
            get
            {
                return idNumTxt.Text;
            }
            set
            {
                idNumTxt.Text = value;
            }
        }

        // Precondition:  none
        // Postcondition: Submits 
        private void okBtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        // Precondition:  
        // Postcondition: 
        private void nameTxt_Validating(object sender, CancelEventArgs e)
        {
            if(nameTxt.Text.Length == 0)
            {
                e.Cancel = true;
                MessageBox.Show("Please enter a name");
            }
        }

        // Precondition:  
        // Postcondition: 
        private void idNumTxt_Validating(object sender, CancelEventArgs e)
        {
            if(idNumTxt.Text.Length == 0)
            {
                e.Cancel = true;
                MessageBox.Show("Please enter an ID");
            }
        }
    }
}
