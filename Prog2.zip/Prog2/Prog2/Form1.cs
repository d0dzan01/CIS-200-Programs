﻿// Grading ID: T2208
// Program 2
// Due Date: March 8, 2020
// Section 01
// This is a GUI application that can report different Library Items as checked out or not,
// and patrons associated with the checked out item

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class Form1 : Form
    {
        private Library _lib;

        // Precondition:  None
        // Postcondition: Loads premade data into the program
        public Form1()
        {
            InitializeComponent();

            _lib = new Library(); // Creates a library

            _lib.AddPatron("Bob Bob", "1");
            _lib.AddPatron("Adam Smith", "2");
            _lib.AddPatron("Cole Ton", "3");

            _lib.AddLibraryBook("The Wright Guide to C#", "UofL Press", 2010, 14,
                "ZZ25 3G", "Andrew Wright");
            _lib.AddLibraryMovie("   Andrew's Super-Duper Movie   ", "   UofL Movies   ", 2019, 7,
                "MM33 2D", 92.5, "   Andrew L. Wright   ", LibraryMediaItem.MediaType.BLURAY,
                LibraryMovie.MPAARatings.PG);
            _lib.AddLibraryMusic("C# - The Album", "UofL Music", 2020, 14,
                "CD44 4Z", 84.3, "Dr. A", LibraryMediaItem.MediaType.CD, 10);
            _lib.AddLibraryJournal("Journal of C# Goodness", "UofL Journals", 2018, 14,
                "JJ12 7M", 1, 2, "Information Systems", "Andrew Wright");
            _lib.AddLibraryMagazine("C# Monthly", "UofL Mags", 2017, 14,
                "MA53 9A", 16, 7);
        }
        string NL = Environment.NewLine; // New line shortcut

        // Precondition:  Click the About menu button
        // Postcondition: Display information about the program
        private void File_About(object sender, EventArgs e)
        {
            MessageBox.Show($"Grading ID: T2208" + NL +
                $"Program 2" + NL +
                $"Due Date: March 8, 2020" + NL +
                $"Section 01" + NL +
                $"This is a GUI application that can report different Library Items as checked out or not, " +
                $"and patrons associated with the checked out item.");
        }

        // Precondition:  Click the Exit menu button
        // Postcondition: Exits the application
        private void File_Exit(object sender, EventArgs e)
        {
            Application.Exit(); // Closes the application
        }

        // Precondition:  Click the Report > Patron List menu button
        // Postcondition: Returns the list of patrons currently in the program
        private void Report_PatronList(object sender, EventArgs e)
        {
            displayTxt.Clear(); // Clears the text box
            displayTxt.Text = $"Patron List - {_lib.GetPatronCount()} Patrons{NL}{NL}";

            foreach (LibraryPatron patron in _lib.GetPatronsList()) // Loops and displays all patrons
                displayTxt.Text += patron + NL + NL;
        }

        // Precondition:  Click the Report > Item List menu button
        // Postcondition: Returns the list of items currently in the library
        private void Report_ItemList(object sender, EventArgs e)
        {
            displayTxt.Clear(); // Clears textbox
            displayTxt.Text = $"Item List - {_lib.GetItemCount()} Items{NL}{NL}";

            foreach (LibraryItem item in _lib.GetItemsList()) // Loops through all items
                displayTxt.Text += item + NL + NL;
        }

        // Precondition:  Click the Report > Checked out items menu button
        // Postcondition: Returns the list of items currently checked out, and by whom
        private void Report_CheckedOutItems(object sender, EventArgs e)
        {
            displayTxt.Clear(); // Clears text box
            displayTxt.Text = $"Checked Out Items - {_lib.GetCheckedOutCount()} Items Checked Out{NL}{NL}";

            foreach (LibraryItem item in _lib.GetItemsList()) // Loops and displays all checked out items
                if (item.IsCheckedOut())
                    displayTxt.Text += item + NL + NL;
        }

        // Precondition:  Click the checkout menu button
        // Postcondition: displays a second form that is completed by the user to check out an item
        private void checkOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CheckOutForm checkOut = new CheckOutForm(_lib.GetItemsList(), _lib.GetPatronsList());
            DialogResult result = checkOut.ShowDialog();
            if (result == DialogResult.OK)
                _lib.CheckOut(checkOut.Items, checkOut.Patrons);
        }

        // Precondition:  Click the return menu button
        // Postcondition: displays a second form that is completed by the user to return an item
        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReturnForm retForm = new ReturnForm(_lib.GetItemsList());
            DialogResult result = retForm.ShowDialog();
            if (result == DialogResult.OK)
                _lib.ReturnToShelf(retForm.Items);
        }

        // Precondition:  Click the new patron menu button
        // Postcondition: displays a second form that is completed by the user to create a new patron
        private void patronToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewPatron patron = new NewPatron();
            DialogResult result = patron.ShowDialog();
            if (result == DialogResult.OK)
                _lib.AddPatron(patron.Name, patron.IdNumber);
        }

        // Precondition:  Click the new book menu button
        // Postcondition: displays a second form that is completed by the user to add a new book to the library
        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewBook book = new NewBook();
            DialogResult result = book.ShowDialog();
            if (result == DialogResult.OK)
                _lib.AddLibraryBook(book.Title, book.Publisher, book.CopyrightYear, book.LoanPeriod, book.CallNumber, book.Author);
        }
    }
}
