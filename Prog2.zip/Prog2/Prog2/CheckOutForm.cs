﻿// Grading ID: T2208
// Program 2
// Due Date: March 8, 2020
// Section 01
// This form checks out an item and assigns it to a particular patron

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class CheckOutForm : Form
    {
        private List<LibraryItem> _items;     // List of items stored in Library
        private List<LibraryPatron> _patrons; // List of patrons of Library

        // Precondition:  None
        // Postcondition: initalizes the list of items and patrons
        public CheckOutForm(List<LibraryItem> items, List<LibraryPatron> patrons)
        {
            InitializeComponent();
            _items = items;
            _patrons = patrons;
        }

        // Precondition:  None
        // Postcondition: Populates the combo box with items and patrons
        private void CheckOutForm_Load(object sender, EventArgs e)
        {
            foreach (LibraryItem item in _items)
                itemCbx.Items.Add(item.Title + ", " + item.CallNumber);
            foreach (LibraryPatron patron in _patrons)
                patronCbx.Items.Add(patron.PatronName + ", " + patron.PatronID);
        }

        // Precondition:  None
        // Postcondition: Gets and sets the selected combo box item
        public int Items
        {
            get
            {
                return itemCbx.SelectedIndex;
            }
            set
            {
                itemCbx.SelectedIndex = value;
            }
        }

        // Precondition:  None
        // Postcondition: Gets and sets the selected combo box patron
        public int Patrons
        {
            get
            {
                return patronCbx.SelectedIndex;
            }
            set
            {
                patronCbx.SelectedIndex = value;
            }
        }

        // Precondition:  None
        // Postcondition: Checks out the selected item and gives it to the patron
        private void okCheckBtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
    }
}
