﻿// Grading ID: T2208
// Program 2
// Due Date: March 8, 2020
// Section 01
// This form creates new books to add to our library

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class NewBook : Form
    {
        public NewBook()
        {
            InitializeComponent();
        }

        // Precondition:  None
        // Postcondition: gets and sets the title information from the text box.
        public string Title
        {
            get
            {
                return titleTxt.Text;
            }
            set
            {
                titleTxt.Text = value;
            }
        }

        // Precondition:  Nope
        // Postcondition: gets and sets the publisher information from the text box.
        public string Publisher
        {
            get
            {
                return publisherTxt.Text;
            }
            set
            {
                publisherTxt.Text = value;
            }
        }

        // Precondition:  Input must be an int
        // Postcondition: gets and sets the copyright year information from the text box.
        public int CopyrightYear
        {
            get
            {
                int year;
                int.TryParse(copyrightTxt.Text, out year);
                return year;
            }
            set
            {
                int year;
                int.TryParse(copyrightTxt.Text, out year);
                year = value;
            }
        }

        // Precondition:  Input must be an int
        // Postcondition: gets and sets the loan period information from the textbox
        public int LoanPeriod
        {
            get
            {
                int loanPeriod;
                int.TryParse(loanPeriodTxt.Text, out loanPeriod);
                return loanPeriod;
            }
            set
            {
                int loanPeriod;
                int.TryParse(loanPeriodTxt.Text, out loanPeriod);
                loanPeriod = value;
            }
        }

        // Precondition:  None
        // Postcondition: gets and sets the call number information from the text box.
        public string CallNumber
        {
            get
            {
                return callNumTxt.Text;
            }
            set
            {
                callNumTxt.Text = value;
            }
        }

        // Precondition:  None
        // Postcondition: gets and sets the author information from the text box.
        public string Author
        {
            get
            {
                return authorTxt.Text;
            }
            set
            {
                authorTxt.Text = value;
            }
        }

        // Precondition:  Text box cannot be empty
        // Postcondition: validates the title
        private void titleTxt_Validating(object sender, CancelEventArgs e)
        {
            if(titleTxt.Text.Length == 0)
            {
                e.Cancel = true;
                MessageBox.Show("Please enter a valid title");
            }
        }

        // Precondition:  Text box cannot be empty
        // Postcondition: validates the copyright year
        private void copyrightTxt_Validating(object sender, CancelEventArgs e)
        {
            if(copyrightTxt.Text.Length == 0)
            {
                e.Cancel = true;
                MessageBox.Show("Please enter a valid copyright year");
            }
        }

        // Precondition:  Text box cannot be empty
        // Postcondition: validates the loan period
        private void loanPeriodTxt_Validating(object sender, CancelEventArgs e)
        {
            if (loanPeriodTxt.Text.Length == 0)
            {
                e.Cancel = true;
                MessageBox.Show("Please enter a valid loan period");
            }
        }

        // Precondition:  Text box cannot be empty
        // Postcondition: validates the call number
        private void callNumTxt_Validating(object sender, CancelEventArgs e)
        {
            if (callNumTxt.Text.Length == 0)
            {
                e.Cancel = true;
                MessageBox.Show("Please enter a valid call number");
            }
        }

        // Precondition:  All validation steps must return false
        // Postcondition: Submits the new book
        private void okBtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            
        }
    }
}
