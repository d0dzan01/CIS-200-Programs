﻿// Grading ID: T2208
// Program 2
// Due Date: March 8, 2020
// Section 01
// This form returns a checked out book to the shelf

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class ReturnForm : Form
    {
        private List<LibraryItem> _items;     // List of items stored in Library

        public ReturnForm(List<LibraryItem> items)
        {
            InitializeComponent();
            _items = items;
        }

        // Precondition:  None
        // Postcondition: Populates the combo box
        private void ReturnForm_Load(object sender, EventArgs e)
        {
            foreach (LibraryItem item in _items)
                itemCbx.Items.Add(item.Title + ", " + item.CallNumber);
        }

        // Precondition:  None
        // Postcondition: Selects the item in the combo box
        public int Items
        {
            get
            {
                return itemCbx.SelectedIndex;
            }
            set
            {
                itemCbx.SelectedIndex = value;
            }
        }

        // Precondition:  None
        // Postcondition: Submits the data in the return form
        private void okBtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
    }
}
