﻿// Program 1B
// CIS 200-01
// Due: 2/20/2020
// By: T2208

// File: Program.cs
// This file creates a small application that tests the LibraryItem hierarchy

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LibraryItems;
using static System.Console;


public class Program
{
    // Precondition:  None
    // Postcondition: The LibraryItem hierarchy has been tested demonstrating polymorphism
    //                in CalcLateFee()
    public static void Main(string[] args)
    {
        const int DAYSLATE = 14; // Number of days late to test each object's CalcLateFee method
        const int LOANCHANGE = 7; // Adding additional days to the loan

        List<LibraryItem> items = new List<LibraryItem>();       // List of library items
        List<LibraryPatron> patrons = new List<LibraryPatron>(); // List of patrons

        // Test data - Magic numbers allowed here
        items.Add(new LibraryBook("The Wright Guide to C#", "UofL Press", 2010, 14,
            "ZZ25 3G", "Andrew Wright"));
        items.Add(new LibraryMovie("   Andrew's Super-Duper Movie   ", "   UofL Movies   ", 2019, 7,
            "MM33 2D", 92.5, "   Andrew L. Wright   ", LibraryMediaItem.MediaType.BLURAY,
            LibraryMovie.MPAARatings.PG)); // Trims?
        items.Add(new LibraryMusic("C# - The Album", "UofL Music", 2020, 14,
            "CD44 4Z", 84.3, "Dr. A", LibraryMediaItem.MediaType.CD, 10));
        items.Add(new LibraryJournal("Journal of C# Goodness", "UofL Journals", 2018, 14,
            "JJ12 7M", 1, 2, "Information Systems", "Andrew Wright"));
        items.Add(new LibraryMagazine("C# Monthly", "UofL Mags", 2017, 14,
            "MA53 9A", 16, 7));

        // My additions
        items.Add(new LibraryBook("The Lightning Thief", "Miramax Books", 2009, 14, 
            "LB47 8E", "Rick Riordan"));
        items.Add(new LibraryMovie("The Avengers", "Marvel Comics", 2014, 7,
            "MM12 3R", 143.0, "Joss Whedon", LibraryMediaItem.MediaType.DVD,
            LibraryMovie.MPAARatings.PG13));
        items.Add(new LibraryMusic("Blinding Lights", "Republic Records", 2020, 14,
            "CD93 4U", 3.21, "The Weeknd", LibraryMediaItem.MediaType.CD, 1));
        items.Add(new LibraryJournal("Mythical Journal", "Student Publications", 2019, 14,
            "FA43 KE", 1, 1, "Entertainment", "Billy Bob"));
        items.Add(new LibraryMagazine("C# Monthly", "UofL Mags", 2017, 14,
            "MA54 9A", 17, 7));
        items.Add(new LibraryMagazine("Java Monthly", "UofL Mags", 2018, 14,
            "MA32 8J", 1, 3));


        // Add patrons
        patrons.Add(new LibraryPatron("Ima Reader", "12345"));
        patrons.Add(new LibraryPatron("Jane Doe", "11223"));
        patrons.Add(new LibraryPatron("   John Smith   ", "   654321   ")); // Trims?

        //*******************************************************************************

        Console.WriteLine("List of items at start:\n");
        foreach (LibraryItem item in items)
            WriteLine($"{item}\n");
        Pause();
        //*******************************************************************************

        // Check out some items
        items[0].CheckOut(patrons[0]);
        items[2].CheckOut(patrons[2]);
        items[4].CheckOut(patrons[1]);

        WriteLine("List of items after checking some out:\n");
        foreach (LibraryItem item in items)
            WriteLine($"{item}\n");
        Pause();
        //*******************************************************************************
        
        // LINQ looking for the items that are checked out
        var outItemsQuery =
            from i in items
            where i.IsCheckedOut()
            select i;

        // Outputs the results of the LINQ
        WriteLine("Items checked out:\n");
        foreach (LibraryItem item in outItemsQuery)
            WriteLine($"{item}\n");
        WriteLine($"There are {outItemsQuery.Count()} items checked out.\n");
        Pause();
        //*******************************************************************************

        // LINQ looking for only the checked out Library Media Items
        var outMediaItemsQuery =
            from i in outItemsQuery
            where i is LibraryMediaItem
            select i;

        // Outputs the results of the LINQ
        WriteLine("Media Items checked out:\n");
        foreach (LibraryItem item in outMediaItemsQuery)
            WriteLine($"{item}\n");
        Pause();
        //*******************************************************************************

        // LINQ looking for Library Magazine Items
        var uniqueMagazineQuery =
            from i in items
            where i is LibraryMagazine
            select i.Title;

        // Outputs ONLY UNIQUE Magazine titles. Duplicates will not be displayed
        WriteLine("Unique Library Magazine Item titles:\n");
        foreach (string title in uniqueMagazineQuery.Distinct())
            WriteLine($"{title}\n");
        Pause();
        //*******************************************************************************

        // Looks neat
        WriteLine($"Calculated late fees after {DAYSLATE} days late:\n");
        WriteLine($"{"Title",30} {"Call Number",11} {"Late Fee",8}");
        WriteLine("------------------------------ ----------- --------");

        // Caluclate and display late fees for each item
        foreach (LibraryItem item in items)
            WriteLine($"{item.Title,30} {item.CallNumber,11} {item.CalcLateFee(DAYSLATE),8:C}");
        Pause();
        //*******************************************************************************

        // Returns all checked out items back to the shelf, then uses the same LINQ from
        // before to prove that LINQ uses deferred execution
        foreach (var item in items)
            if(item.IsCheckedOut())
                item.ReturnToShelf();
        WriteLine("Items checked out:\n");
        foreach (LibraryItem item in outItemsQuery)
            WriteLine($"{item}\n");
        WriteLine($"There are {outItemsQuery.Count()} items checked out.\n");
        Pause();
        //*******************************************************************************

        // Loops through each Library Book, displays its current Loan Period, then adds the
        // constant LOANCHANGE to the loan period (7), and then displays the new loan period
        foreach (var book in items)
        {
            if (book is LibraryBook)
            {
                Write($"{book.Title} has a current loan period of {book.LoanPeriod} days. ");
                book.LoanPeriod += LOANCHANGE;
                WriteLine($"With the loan period change, the new loan period is {book.LoanPeriod} days.");
            }
        }
        Pause();
        //*******************************************************************************

        // Lists the items again
        WriteLine("List of items:\n");
        foreach (LibraryItem item in items)
            WriteLine($"{item}\n");
        Pause();

    }

    // Precondition:  None
    // Postcondition: Pauses program execution until user presses Enter and
    //                then clears the screen
    public static void Pause()
    {
        WriteLine("Press Enter to Continue...");
        ReadLine();

        Clear(); // Clear screen
    }
}